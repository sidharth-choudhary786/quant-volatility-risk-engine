# quant-volatility-risk-engine
Quantitative volatility modeling and risk management framework for Indian equities, covering GARCH-family models, portfolio risk aggregation, stress testing, and execution-aware strategy evaluation with robust out-of-sample validation.
